//
//  NMessengerVCTests.swift
//  n1
//
//  Created by Tainter, Aaron on 5/13/16.
//  Copyright © 2016 Ebay Inc. All rights reserved.
//

import Foundation
import XCTest
@testable import nMessenger

class NMessengerVCTests: XCTestCase {
    
    func testVC() {
        //TODO:
    }
    
}
