#import <UIKit/UIKit.h>

//! Project version number for nMessenger-iOS.
FOUNDATION_EXPORT double nMessenger_iOSVersionNumber;

//! Project version string for nMessenger-iOS.
FOUNDATION_EXPORT const unsigned char nMessenger_iOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <nMessenger_iOS/PublicHeader.h>


